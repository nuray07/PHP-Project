-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 17, 2018 at 09:31 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--
CREATE DATABASE IF NOT EXISTS `registration` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `registration`;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(225) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `phone`) VALUES
(32, 'NurayRaim', '1e94176c90ae217aa827093fcff760a3', 'nurayhusnu@gmail.com', '1234'),
(31, 'Nurayhusnu', 'd2e28b18072b8c1729521a8293086ce4', 'nurayhusnu@gmail.com', '444-444'),
(30, 'Nurayhusnu', 'd2e28b18072b8c1729521a8293086ce4', 'nurayhusnu@gmail.com', '615151'),
(29, 'Nurayhusnu', 'fcea920f7412b5da7be0cf42b8c93759', 'nurayhusnu@gmail.com', '615151'),
(28, 'Nurayhusnu', 'd2e28b18072b8c1729521a8293086ce4', 'nurayhusnu@gmail.com', '4848'),
(27, 'Nurayhusnu', 'd2e28b18072b8c1729521a8293086ce4', 'adwada@gmail.com', '55161651'),
(26, 'Nurayhusnu', 'd2e28b18072b8c1729521a8293086ce4', 'adwada@gmail.com', '36118185');
--
-- Database: `sklad`
--
CREATE DATABASE IF NOT EXISTS `sklad` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sklad`;

-- --------------------------------------------------------

--
-- Table structure for table `hranitelni_stoki`
--

DROP TABLE IF EXISTS `hranitelni_stoki`;
CREATE TABLE IF NOT EXISTS `hranitelni_stoki` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(225) NOT NULL,
  `purchase_price` varchar(255) NOT NULL,
  `selling_price` varchar(255) NOT NULL,
  `quantity` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=118 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hranitelni_stoki`
--

INSERT INTO `hranitelni_stoki` (`id`, `name`, `purchase_price`, `selling_price`, `quantity`) VALUES
(114, ' ad', 'daddw', ' dwada', ' dadaw'),
(113, ' ala', ' ', ' ', ' '),
(108, ' ', ' ', ' ', ' '),
(117, ' Cola ', '4', '6', '10');

-- --------------------------------------------------------

--
-- Table structure for table `kancelarski_materiali`
--

DROP TABLE IF EXISTS `kancelarski_materiali`;
CREATE TABLE IF NOT EXISTS `kancelarski_materiali` (
  `id_km` int(11) NOT NULL AUTO_INCREMENT,
  `name_km` varchar(225) NOT NULL,
  `purchase_price_km` varchar(255) NOT NULL,
  `selling_price_km` varchar(255) NOT NULL,
  `quantity_km` varchar(255) NOT NULL,
  PRIMARY KEY (`id_km`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kancelarski_materiali`
--

INSERT INTO `kancelarski_materiali` (`id_km`, `name_km`, `purchase_price_km`, `selling_price_km`, `quantity_km`) VALUES
(4, ' ala', 'bala', ' ', ' '),
(3, ' ddadw', '  ', '  ', '  ');

-- --------------------------------------------------------

--
-- Table structure for table `stroitelni_materiali`
--

DROP TABLE IF EXISTS `stroitelni_materiali`;
CREATE TABLE IF NOT EXISTS `stroitelni_materiali` (
  `id_sm` int(11) NOT NULL AUTO_INCREMENT,
  `name_sm` varchar(225) NOT NULL,
  `purchase_price_sm` varchar(255) NOT NULL,
  `selling_price_sm` varchar(255) NOT NULL,
  `quantity_sm` varchar(255) NOT NULL,
  PRIMARY KEY (`id_sm`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stroitelni_materiali`
--

INSERT INTO `stroitelni_materiali` (`id_sm`, `name_sm`, `purchase_price_sm`, `selling_price_sm`, `quantity_sm`) VALUES
(1, ' ', ' ', ' ', ' '),
(2, ' ', ' ', ' ', ' ');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
